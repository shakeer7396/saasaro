import './App.css';

import Mycomponent from './Components/Mycomponent';

function App() {
  return (
    <div className="App">
      
        <Mycomponent />
    </div>
  );
}

export default App;
